#ifndef DRONE_H
#define DRONE_H

typedef struct {
    float pos[3];     // Position (x, y, z)
    float vel[3];     // Vitesse
    float acc[3];     // Accélération
    float angularAcc[3];// Accélération angulaire
    float angularVel[3];    // Vitesse angulaire
    float angularDampingCoefficient;
    float rot[3];     // Rotation (pitch, yaw, roll)
    float torque[3];  // Couple angulaire
    float rotorSpeed[4];  // vitesses des 4 rotors (0 à 1 ou en tours/min)
    float rotorMaxThrust; // poussée maximale d’un rotor
    float force[3];    // Force linéaire totale (N)
    float mass;
    float momentOfInertia;
    float linearDragCoefficient;
} Drone;

// FONCTIONS
// Drone 
void drone_update(Drone * drone, double dt);
void init_drone(Drone * drone);
void clamp_rotorSpeed(Drone * drone);

// Calcul des forces
void apply_force(Drone* drone, float fx, float fy, float fz);
void apply_force_local(Drone* drone, float fx, float fy, float fz);

#endif  // DRONE_H