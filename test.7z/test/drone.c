#include "lib.h"
#include "drone.h"


void init_drone(Drone * drone) {
    memset(drone, 0, sizeof(Drone));
    drone->pos[0] = 0.0f;
    drone->pos[1] = 0.0f;
    drone->pos[2] = -5.0f;  // pour qu'on voie le drone au démarrage

    drone->mass = 1.0f;

    drone->rotorMaxThrust = 10.0f;

    drone->momentOfInertia = 10.0f;

    drone->linearDragCoefficient = 0.5f;
    drone->angularDampingCoefficient = 0.5f;
}

void clamp_rotorSpeed(Drone * drone) {
    for (int i = 0; i < 4; i++) {
        if (drone->rotorSpeed[i] < 0.0f) drone->rotorSpeed[i] = 0.0f;
        if (drone->rotorSpeed[i] > 1.0f) drone->rotorSpeed[i] = 1.0f;
    }
}

void apply_force(Drone* drone, float fx, float fy, float fz) {
    drone->force[0] += fx;
    drone->force[1] += fy;
    drone->force[2] += fz;
}

void apply_force_local(Drone* drone, float fx, float fy, float fz) {
    float pitch_rad = drone->rot[0] * (M_PI / 180.0f); // Rotation around X-axis
    float yaw_rad   = drone->rot[1] * (M_PI / 180.0f);   // Rotation around Y-axis
    float roll_rad  = drone->rot[2] * (M_PI / 180.0f);  // Rotation around Z-axis

    // Step 1: Initialize the rotated vector with the local force components
    float rotatedX = fx;
    float rotatedY = fy;
    float rotatedZ = fz;

    // Step 2: Apply Yaw (rotation around Y-axis)
    float cosYaw = cosf(yaw_rad);
    float sinYaw = sinf(yaw_rad);
    float tempX = rotatedX * cosYaw + rotatedZ * sinYaw;
    float tempZ = -rotatedX * sinYaw + rotatedZ * cosYaw;
    rotatedX = tempX;
    rotatedZ = tempZ;
    // rotatedY remains unchanged by yaw

    // Step 3: Apply Pitch (rotation around X-axis)
    float cosPitch = cosf(pitch_rad);
    float sinPitch = sinf(pitch_rad);
    float tempY = rotatedY * cosPitch - rotatedZ * sinPitch;
    tempZ = rotatedY * sinPitch + rotatedZ * cosPitch;
    rotatedY = tempY;
    rotatedZ = tempZ;
    // rotatedX remains unchanged by pitch

    // Step 4: Apply Roll (rotation around Z-axis)
    float cosRoll = cosf(roll_rad);
    float sinRoll = sinf(roll_rad);
    tempX = rotatedX * cosRoll - rotatedY * sinRoll;
    tempY = rotatedX * sinRoll + rotatedY * cosRoll;
    rotatedX = tempX;
    rotatedY = tempY;
    // rotatedZ remains unchanged by roll

    // The final rotated vector is now (rotatedX, rotatedY, rotatedZ)
    apply_force(drone, rotatedX, rotatedY, rotatedZ);
}

void drone_update(Drone * drone, double dt) { 
    // On calcule le thrust
    float thrust[4];
    for (int i = 0; i < 4; i++) {
        thrust[i] = drone->rotorSpeed[i] * drone->rotorMaxThrust;
        printf("%f ", drone->rotorSpeed[i]);
    }
    puts("");

    // Force totale de poussée 
    float totalThrust = thrust[0] + thrust[1] + thrust[2] + thrust[3];
    printf("Total Thrust: %f, Gravity: %f\n", totalThrust, drone->mass * 9.81f);

    // On applique la force de poussée localement 
    apply_force_local(drone, 0.0f, totalThrust, 0.0f);

    // On applique les forces
    drone->torque[0] = (thrust[2] + thrust[3]) - (thrust[0] + thrust[1]);
    drone->torque[1] = -thrust[0] + thrust[1] - thrust[2] + thrust[3];
    drone->torque[2] = (thrust[1] + thrust[2]) - (thrust[0] + thrust[3]);

    // TODO : Appliquer forces de torque
    drone->angularAcc[0] = drone->torque[0] / drone->momentOfInertia; // For pitch
    drone->angularAcc[1] = drone->torque[1] / drone->momentOfInertia; // For yaw
    drone->angularAcc[2] = drone->torque[2] / drone->momentOfInertia; // For roll

    drone->angularVel[0] += drone->angularAcc[0] * dt;
    drone->angularVel[1] += drone->angularAcc[1] * dt;
    drone->angularVel[2] += drone->angularAcc[2] * dt;

    // Atténuations angulaires
    drone->angularVel[0] *= (1.0f - drone->angularDampingCoefficient * dt);
    drone->angularVel[1] *= (1.0f - drone->angularDampingCoefficient * dt);
    drone->angularVel[2] *= (1.0f - drone->angularDampingCoefficient * dt);

    // Integrate angular velocity into rotation (convert degrees to radians for sin/cos)
    drone->rot[0] += drone->angularVel[0] * dt * (180.0f / M_PI); // Convert back to degrees
    drone->rot[1] += drone->angularVel[1] * dt * (180.0f / M_PI);
    drone->rot[2] += drone->angularVel[2] * dt * (180.0f / M_PI);

    // Gravité
    apply_force(drone, 0.0f, -drone->mass * 9.81f, 0.0f);

    // Force de trainée
    float speedSq = drone->vel[0]*drone->vel[0] + drone->vel[1]*drone->vel[1] + drone->vel[2]*drone->vel[2];
    float speed = sqrtf(speedSq);
    if (speed > 0.001f) { // Avoid division by zero with very small speeds
        float dragMagnitude = drone->linearDragCoefficient * speedSq;
        drone->force[0] -= (drone->vel[0] / speed) * dragMagnitude;
        drone->force[1] -= (drone->vel[1] / speed) * dragMagnitude;
        drone->force[2] -= (drone->vel[2] / speed) * dragMagnitude;
    }

    printf("Fx = %f, Fy = %f, Fz = %f\n", drone->force[0], drone->force[1], drone->force[2]);
    // Intégration physique
    float acc[3];
    for (int i = 0; i < 3; i++) {
        acc[i] = drone->force[i] / drone->mass;
        drone->vel[i] += acc[i] * dt;
        drone->pos[i] += drone->vel[i] * dt;
    }

    // Rotation
    //     drone->rot[0] += drone->torque[0] * dt; // pitch
    //     drone->rot[1] += drone->torque[1] * dt; // yaw
    //     drone->rot[2] += drone->torque[2] * dt; // roll


    // // Met à jour la vitesse
    // drone->vel[0] += drone->acc[0] * dt;
    // drone->vel[1] += drone->acc[1] * dt;
    // drone->vel[2] += drone->acc[2] * dt;

    // // Met à jour la position
    // drone->pos[0] += drone->vel[0] * dt;
    // drone->pos[1] += drone->vel[1] * dt;
    // drone->pos[2] += drone->vel[2] * dt;


    // Vérifie la collision avec le sol
    if(drone->pos[1]<=1)drone->pos[1]=1;

    // drone->acc[0] = 0;
    // drone->acc[1] = 0;
    // drone->acc[2] = 0;

    // drone->torque[0] = 0;
    // drone->torque[1] = 0;
    // drone->torque[2] = 0;

    // On reset les forces pour la prochaine frame
    for (int i = 0; i < 3; i++) {
        drone->force[i] = 0;
        drone->torque[i] = 0;
    }
}