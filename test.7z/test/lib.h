#ifndef LIB_H
#define LIB_H

#include <SDL/SDL.h>
#include <SDL/SDL_gfxPrimitives.h>
#include <SDL/SDL_opengl.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
// Spécial Windows
#ifdef _WIN32
#include <windows.h>
#endif


#endif  // LIB_H