#include "lib.h"
#include "input.h"
#include "globals.h"
#include "./map/map_perlin.h"
#include "./math3d.h"

//       [0]         [1]
//      rotor0     rotor1
//        \         /
//         \       /
//          \     /
//           \   /
//            [X]
//           /   \
//          /     \
//     rotor3     rotor2
//     [3]         [2]
int mode_fps = 0;

void SDL_event_listener(Drone * drone, double dt) {
    SDL_Event event;
    const Uint8* keystates = SDL_GetKeyState(NULL);
    while(SDL_PollEvent(&event)) {
        if (event.type == SDL_KEYDOWN) {
            switch (event.key.keysym.sym) {
                // case SDLK_w: drone->acc[2] -= 10.0f; break; // avant
                // case SDLK_s: drone->acc[2] += 10.0f; break; // arrière
                // case SDLK_SPACE: drone->acc[1] += 15.0f; break; // monter
                // case SDLK_LCTRL: drone->acc[1] -= 15.0f; break; // descendre
                // case SDLK_a: drone->torque[1] -= 1.0f; break; // yaw gauche
                // case SDLK_d: drone->torque[1] += 1.0f; break; // yaw droite

                case SDLK_SPACE:
                    for (int i = 0; i < 4; i++)
                        drone->rotorSpeed[i] += ROTOR_ADJUST;
                    break;
                case SDLK_LCTRL:
                    for (int i = 0; i < 4; i++)
                        drone->rotorSpeed[i] -= ROTOR_ADJUST;
                    break;
                case SDLK_l:
                            mode_fps = !mode_fps;
                            SDL_ShowCursor(mode_fps ? SDL_DISABLE : SDL_ENABLE);
                            break;
                case SDLK_z: // pitch avant
                    drone->rotorSpeed[0] -= ROTOR_ADJUST;
                    drone->rotorSpeed[1] -= ROTOR_ADJUST;
                    drone->rotorSpeed[2] += ROTOR_ADJUST;
                    drone->rotorSpeed[3] += ROTOR_ADJUST;
                    break;
                case SDLK_s: // pitch arrière
                    drone->rotorSpeed[0] += ROTOR_ADJUST;
                    drone->rotorSpeed[1] += ROTOR_ADJUST;
                    drone->rotorSpeed[2] -= ROTOR_ADJUST;
                    drone->rotorSpeed[3] -= ROTOR_ADJUST;
                    break;
                case SDLK_a: // roll gauche
                    drone->rotorSpeed[0] -= ROTOR_ADJUST;
                    drone->rotorSpeed[3] -= ROTOR_ADJUST;
                    drone->rotorSpeed[1] += ROTOR_ADJUST;
                    drone->rotorSpeed[2] += ROTOR_ADJUST;
                    break;
                case SDLK_d: // roll droite
                    drone->rotorSpeed[0] += ROTOR_ADJUST;
                    drone->rotorSpeed[3] += ROTOR_ADJUST;
                    drone->rotorSpeed[1] -= ROTOR_ADJUST;
                    drone->rotorSpeed[2] -= ROTOR_ADJUST;
                    break;
                case SDLK_q: // yaw gauche
                    drone->rotorSpeed[0] += ROTOR_ADJUST;
                    drone->rotorSpeed[2] += ROTOR_ADJUST;
                    drone->rotorSpeed[1] -= ROTOR_ADJUST;
                    drone->rotorSpeed[3] -= ROTOR_ADJUST;
                    break;
                case SDLK_e: // yaw droite
                    drone->rotorSpeed[0] -= ROTOR_ADJUST;
                    drone->rotorSpeed[2] -= ROTOR_ADJUST;
                    drone->rotorSpeed[1] += ROTOR_ADJUST;
                    drone->rotorSpeed[3] += ROTOR_ADJUST;
                    break;
                case SDLK_o: // Décollage
                    for(int i=0; i<4; i++) {
                        drone->rotorSpeed[i] = ((drone->mass * 9.81f) / 4.0f) / drone->rotorMaxThrust;
                    }
                    break;
                case SDLK_ESCAPE: running = 0; break;
            }
        }

        if(event.type == SDL_QUIT) {
            running = 0;    
        }
        
    }
    if (mode_fps){
        update_camera_fps(keystates, dt);
        affichage(NULL, 0, 0, 0); // drone inutile ici
    }
    else{
        affichage(drone, 0, 0, 0);
    }
    // On clamp les vitesses des rotors entre 0 et 1
    clamp_rotorSpeed(drone);
}