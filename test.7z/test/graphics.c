#include "lib.h"
#include "graphics.h"

void init_SDL() {
    SDL_Init(SDL_INIT_VIDEO);
    SDL_SetVideoMode(800, 600, 32, SDL_OPENGL);
    SDL_WM_SetCaption("Simulation Drone 3D", NULL);

    glEnable(GL_DEPTH_TEST);
    glMatrixMode(GL_PROJECTION);
    gluPerspective(60.0, 800.0/600.0, 0.1, 1000.0);
    glMatrixMode(GL_MODELVIEW);

    glClearColor(0.1f, 0.1f, 0.2f, 1.0f);  // fond bleu foncé
}

void update_camera(const Drone *drone,
                   float distance_derriere,
                   float hauteur_cam,
                   float target_offset_y)
{
    // 1. on est bien en MODELVIEW
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    // 2. calcul du yaw en radians
    float yaw_rad = drone->rot[1] * (M_PI / 180.0f);
    float fx = sinf(yaw_rad), fz = cosf(yaw_rad);

    // 3. position de la caméra
    float camX = drone->pos[0] - fx * distance_derriere;
    float camY = drone->pos[1] + hauteur_cam;
    float camZ = drone->pos[2] - fz * distance_derriere;

    // 4. point visé (on ajoute target_offset_y, typiquement négatif)
    float tgtX = drone->pos[0] + fx;
    float tgtY = drone->pos[1] + target_offset_y;
    float tgtZ = drone->pos[2] + fz;

    // 5. on appelle gluLookAt
    gluLookAt(
        camX,    camY,    camZ,
        tgtX,    tgtY,    tgtZ,
        0.0f,    1.0f,    0.0f
    );
}

void render_drone(Drone * drone){
    glPushMatrix();
    glTranslatef(drone->pos[0], drone->pos[1], drone->pos[2]);
    glRotatef(drone->rot[0], 1, 0, 0); // pitch
    glRotatef(drone->rot[1], 0, 1, 0); // yaw
    glRotatef(drone->rot[2], 0, 0, 1); // roll

    glBegin(GL_QUADS);
    // cube simple ou croix pour drone
    glVertex3f(-0.5f, 0, -0.5f); glVertex3f(0.5f, 0, -0.5f);
    glVertex3f(0.5f, 0, 0.5f); glVertex3f(-0.5f, 0, 0.5f);
    glEnd();

    glPopMatrix();
}

void render_ground() {
    // Couleur du sol
    glColor3f(0.0f, 0.6f, 0.0f);  // vert
    glBegin(GL_QUADS);
    glVertex3f(-50.0f, 0.0f, -50.0f);
    glVertex3f( 50.0f, 0.0f, -50.0f);
    glVertex3f( 50.0f, 0.0f,  50.0f);
    glVertex3f(-50.0f, 0.0f,  50.0f);
    glEnd();

    // Grille noir
    glColor3f(0.0f, 0.0f, 0.0f);  // noir
    glBegin(GL_LINES);
    for (float i = -50.0f; i <= 50.0f; i += 1.0f) {
        // lignes parallèles à X
        glVertex3f(i, 0.01f, -50.0f);
        glVertex3f(i, 0.01f,  50.0f);

        // lignes parallèles à Z
        glVertex3f(-50.0f, 0.01f, i);
        glVertex3f( 50.0f, 0.01f, i);
    }
    glEnd();
}



void affichage(Drone * drone) {
    glLoadIdentity();
    update_camera(drone,
                  /*distance*/         10.0f,
                  /*hauteur_cam*/       5.0f,
                  /*target_offset_y*/  -1.0f);

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    render_ground();
    render_drone(drone);
    SDL_GL_SwapBuffers();
}