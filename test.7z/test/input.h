#ifndef INPUT_H
#define INPUT_H

#include "drone.h"

#define ROTOR_ADJUST 0.01f

void SDL_event_listener(Drone * drone, double dt);


#endif  // INPUT_H