#ifndef MATH3D_H
#define MATH3D_H

typedef struct { double x, y, z; } Vec3;
typedef struct { double w, x, y, z; } Quaternion;

#endif